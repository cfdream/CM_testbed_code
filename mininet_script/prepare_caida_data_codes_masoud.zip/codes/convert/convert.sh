#!/bin/bash
for file in ${1}/*130000*.csv
do
	java -jar convert.jar $file ${2}/`basename $file`
done
