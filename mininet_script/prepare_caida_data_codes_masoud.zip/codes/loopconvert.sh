#!/bin/bash
#for i in {0..9}
#do
#   wget -np -m --http-password=caida  --http-user=moshrefj@usc.edu --no-check-certificate https://data.caida.org/datasets/passive-2012/equinix-sanjose/20120318-130000.UTC/equinix-sanjose.dirA.20120418-130${i}00.UTC.anon.pcap.gz
#done

for i in {13..59}
do
    ./script.sh equinix-sanjose.dirA.20120119-13${i}00.UTC.anon.pcap
#   wget -np -m --http-password=caida  --http-user=moshrefj@usc.edu --no-check-certificate https://data.caida.org/datasets/passive-2012/equinix-sanjose/20120119-130000.UTC/equinix-sanjose.dirA.20120119-13${i}00.UTC.anon.pcap.gz
done

