#!/bin/bash
for i in {0..9}
do
    echo $i `head -n 1 equinix-sanjose.dirA.20121018-130${i}00.UTC.anon.pcap.csv`
    echo $i `tail -n 1 equinix-sanjose.dirA.20121018-130${i}00.UTC.anon.pcap.csv`
done

for i in {10..59}
do
    echo $i `head -n 1 equinix-sanjose.dirA.20121018-13${i}00.UTC.anon.pcap.csv`
    echo $i `tail -n 1 equinix-sanjose.dirA.20121018-13${i}00.UTC.anon.pcap.csv`
done

